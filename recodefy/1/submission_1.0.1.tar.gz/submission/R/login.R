#' Function to set the username/password
#' @export
login <- function(){
  email <- svDialogs::dlgInput("Enter email", "")$res
  password <- svDialogs::dlgInput("Enter password", "")$res

  res = httr::POST(url="https://apiautograder.recodefy.com/login", 
                  body=list(email=email, password=password))

  if (res$status_code == 200){
    svDialogs::dlg_message("Login Successful")
    accessToken = httr::content(res)$accessToken
    if (exists("accessToken") && length(accessToken) > 0){
      options(SUBMISSION_ACCESS_TOKEN=accessToken)
    }
  }
  else{
    svDialogs::dlg_message("Unable to login. Please try again")
  }
}
