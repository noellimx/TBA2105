#' Function to submit script
#' @export
submitScript <- function(){
  
  path <- rstudioapi::getSourceEditorContext()$path

  #save file
  rstudioapi::documentSave(rstudioapi::getSourceEditorContext()$id)

  exercise = ""

  #check for #Ex:
  con = file(path, "r")
  while(TRUE){
    line = readLines(con, n = 1)
    if (length(line) == 0){
      break
    }

    line = sub("^\\s+", "", line)
    
    if (substr(line, 1, 3) == "#Ex"){
      tokens = strsplit(line, "\\s+")
      exercise = tokens[[1]][2]
      break;
    }
  }

  close(con)

  if (exercise == ""){
    svDialogs::dlg_message("Ensure that the first line of the code has #Ex [EXERCISE_ID]")
    return()
  }
  
  if (length(path) == 0 || path == ""){
    svDialogs::dlg_message("Open script in the editor and save the script before submitting")
    return()
  } else{
    accessToken <- getOption("SUBMISSION_ACCESS_TOKEN")
    if (is.null(accessToken)){
      email <- svDialogs::dlgInput("Enter email", "")$res
      password <- svDialogs::dlgInput("Enter password", "")$res

      res = httr::POST(url="https://apiautograder.recodefy.com/login", 
                      body=list(email=email, password=password))

      if (res$status_code == 200){
        accessToken = httr::content(res)$accessToken
        if (exists("accessToken") && length(accessToken) > 0){
          options(SUBMISSION_ACCESS_TOKEN=accessToken)
        }
        else{
          svDialogs::dlg_message("Unable to login. Please try again")
          return()          
        }
      }
      else{
        svDialogs::dlg_message("Unable to login. Please try again")
        return()
      }
    }
    
    res = httr::POST(url=paste0("https://apiautograder.recodefy.com/exercises/", exercise, "/submissions"), 
                     body=list(submission=httr::upload_file(file.path(path))),
                     httr::add_headers("Content-Type"="multipart/form-data", "Authorization"=paste0("Bearer ", accessToken)))
    
    if (res$status_code == 401){
      #invalid token, need to log in again
      options(SUBMISSION_ACCESS_TOKEN=NULL)
      svDialogs::dlg_message(paste0("Unable to upload: ", path, ". Please try again"))
    } else if (res$status_code != 204){
      svDialogs::dlg_message(paste0("Unable to upload: ", path, " - ",httr::content(res)$error))
    }
    else{
      svDialogs::dlg_message(paste0("Submitted: ", path))
    }
  }
}
